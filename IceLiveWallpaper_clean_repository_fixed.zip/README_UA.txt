ICE LIVE WALLPAPER — Android project

Це вихідний Android-проєкт живих шпалер (WallpaperService), а не готовий APK.
Проєкт розрахований на JDK 17, Gradle 8.7 та Android Gradle Plugin 8.6.1.

Структура архіву вже підготовлена для кореня GitHub-репозиторію:
у корені мають лежати build.gradle, settings.gradle, app/ та .github/.
Не створюйте додаткову зовнішню папку навколо цих файлів.

Збірка через GitHub Actions:
1. Завантажити ВМІСТ цього архіву безпосередньо в корінь репозиторію.
2. Відкрити Actions → Build Android APK → Run workflow.
3. Після успішного запуску завантажити artifact IceLiveWallpaper-debug.
4. Розпакувати artifact і встановити app-debug.apk на телефон.

Технічні примітки:
- Відео готується та відтворюється лише коли шпалери видимі.
- При приховуванні шпалер відтворення призупиняється.
- MP4 виключено зі стиснення APK, оскільки openRawResourceFd працює лише з нестисненими ресурсами.
- Якщо MediaPlayer завершується помилкою, у Logcat використовується тег IceLiveWallpaper.

APK у цьому архіві не міститься. Збірку та фактичне відтворення на OnePlus 7T Pro
потрібно перевірити після запуску GitHub Actions та встановлення APK на телефон.
