package com.example.icelivewallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class IceWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoWallpaperEngine()

    inner class VideoWallpaperEngine : Engine() {
        private var player: MediaPlayer? = null
        private var visible = false
        private var prepared = false
        private var fallbackBitmap: Bitmap? = null

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            fallbackBitmap = BitmapFactory.decodeResource(resources, R.drawable.winter_peak)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            drawFallback(holder)
            startVideo(holder)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (player == null) drawFallback(holder)
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            val current = player
            if (visibleNow) {
                if (current == null) {
                    if (surfaceHolder.surface.isValid) startVideo(surfaceHolder)
                } else if (prepared) {
                    try { if (!current.isPlaying) current.start() } catch (_: IllegalStateException) {
                        showFallbackAndRestart()
                    }
                }
            } else {
                try { if (prepared && current?.isPlaying == true) current.pause() } catch (_: IllegalStateException) { }
            }
        }

        private fun startVideo(holder: SurfaceHolder) {
            if (!holder.surface.isValid) return
            releasePlayer()
            drawFallback(holder)

            val mp = MediaPlayer()
            player = mp
            prepared = false
            try {
                val afd = resources.openRawResourceFd(R.raw.mountain_lake)
                try {
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                } finally {
                    afd.close()
                }
                mp.setDisplay(holder)
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                mp.setOnPreparedListener { readyPlayer ->
                    if (player !== readyPlayer) return@setOnPreparedListener
                    prepared = true
                    if (visible || isPreview) {
                        try { readyPlayer.start() } catch (_: IllegalStateException) {
                            showFallbackAndRestart()
                        }
                    }
                }
                mp.setOnErrorListener { failedPlayer, _, _ ->
                    if (player === failedPlayer) showFallbackAndRestart()
                    true
                }
                mp.setOnCompletionListener { completedPlayer ->
                    if (player === completedPlayer) {
                        try { completedPlayer.seekTo(0); if (visible || isPreview) completedPlayer.start() }
                        catch (_: IllegalStateException) { showFallbackAndRestart() }
                    }
                }
                mp.prepareAsync()
            } catch (_: Exception) {
                if (player === mp) showFallbackAndRestart()
            }
        }

        private fun showFallbackAndRestart() {
            val old = player
            player = null
            prepared = false
            try { old?.setOnPreparedListener(null); old?.setOnErrorListener(null); old?.release() }
            catch (_: Exception) { }
            if (surfaceHolder.surface.isValid) drawFallback(surfaceHolder)
        }

        private fun drawFallback(holder: SurfaceHolder) {
            val bitmap = fallbackBitmap ?: return
            if (!holder.surface.isValid) return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val srcWidth = bitmap.width
                    val srcHeight = bitmap.height
                    val scale = maxOf(canvas.width.toFloat() / srcWidth, canvas.height.toFloat() / srcHeight)
                    val drawWidth = (srcWidth * scale).toInt()
                    val drawHeight = (srcHeight * scale).toInt()
                    val left = (canvas.width - drawWidth) / 2
                    val top = (canvas.height - drawHeight) / 2
                    val dest = Rect(left, top, left + drawWidth, top + drawHeight)
                    canvas.drawBitmap(bitmap, null, dest, null)
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) { }
            }
        }

        private fun releasePlayer() {
            val old = player
            player = null
            prepared = false
            try { old?.setOnPreparedListener(null); old?.setOnErrorListener(null); old?.setOnCompletionListener(null); old?.release() }
            catch (_: Exception) { }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            releasePlayer()
            try { fallbackBitmap?.recycle() } catch (_: Exception) { }
            fallbackBitmap = null
            super.onDestroy()
        }
    }
}
