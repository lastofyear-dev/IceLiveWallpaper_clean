package com.example.icelivewallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder

class IceWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoWallpaperEngine()

    inner class VideoWallpaperEngine : Engine() {
        private var player: MediaPlayer? = null
        private var visible = false
        private var prepared = false
        private var fallbackBitmap: Bitmap? = null

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            fallbackBitmap = BitmapFactory.decodeResource(resources, R.drawable.winter_peak)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            drawFallback(holder)
            // Do not prepare or decode video while the wallpaper is hidden.
            if (visible) startVideo(holder)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (player == null) drawFallback(holder)
        }

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            val current = player

            if (!visibleNow) {
                if (prepared && current != null) {
                    try {
                        if (current.isPlaying) current.pause()
                    } catch (e: IllegalStateException) {
                        Log.w(TAG, "Unable to pause video after wallpaper became hidden", e)
                        showFallbackAndRelease(current)
                    }
                }
                return
            }

            if (current == null) {
                if (surfaceHolder.surface.isValid) startVideo(surfaceHolder)
            } else if (prepared) {
                try {
                    if (!current.isPlaying) current.start()
                } catch (e: IllegalStateException) {
                    Log.e(TAG, "Unable to resume prepared wallpaper video", e)
                    showFallbackAndRelease(current)
                }
            }
            // If preparation is still in progress, OnPreparedListener will observe visible=true.
        }

        private fun startVideo(holder: SurfaceHolder) {
            if (!visible || !holder.surface.isValid || player != null) return

            drawFallback(holder)
            val mp = MediaPlayer()
            player = mp
            prepared = false

            try {
                val afd = resources.openRawResourceFd(R.raw.mountain_lake)
                    ?: throw IllegalStateException("mountain_lake.mp4 is compressed; openRawResourceFd returned null")
                try {
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                } finally {
                    afd.close()
                }

                mp.setDisplay(holder)
                mp.isLooping = true
                mp.setVolume(0f, 0f)

                mp.setOnPreparedListener { readyPlayer ->
                    if (player !== readyPlayer) return@setOnPreparedListener
                    prepared = true
                    Log.i(TAG, "Wallpaper video prepared; visible=$visible")
                    if (visible) {
                        try {
                            readyPlayer.start()
                            Log.i(TAG, "Wallpaper video playback started")
                        } catch (e: IllegalStateException) {
                            Log.e(TAG, "Unable to start prepared wallpaper video", e)
                            showFallbackAndRelease(readyPlayer)
                        }
                    }
                }

                mp.setOnErrorListener { failedPlayer, what, extra ->
                    if (player === failedPlayer) {
                        Log.e(TAG, "MediaPlayer error: what=$what extra=$extra")
                        showFallbackAndRelease(failedPlayer)
                    }
                    true
                }

                mp.prepareAsync()
                Log.i(TAG, "Wallpaper video preparation requested")
            } catch (e: Exception) {
                Log.e(TAG, "Unable to prepare wallpaper video", e)
                if (player === mp) showFallbackAndRelease(mp)
            }
        }

        private fun showFallbackAndRelease(failedPlayer: MediaPlayer) {
            if (player !== failedPlayer) return
            player = null
            prepared = false
            try {
                failedPlayer.setOnPreparedListener(null)
                failedPlayer.setOnErrorListener(null)
                failedPlayer.setOnCompletionListener(null)
                failedPlayer.release()
            } catch (e: Exception) {
                Log.w(TAG, "Error while releasing failed MediaPlayer", e)
            }
            if (surfaceHolder.surface.isValid) drawFallback(surfaceHolder)
        }

        private fun drawFallback(holder: SurfaceHolder) {
            val bitmap = fallbackBitmap ?: return
            if (!holder.surface.isValid) return

            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val scale = maxOf(
                        canvas.width.toFloat() / bitmap.width,
                        canvas.height.toFloat() / bitmap.height
                    )
                    val drawWidth = (bitmap.width * scale).toInt()
                    val drawHeight = (bitmap.height * scale).toInt()
                    val left = (canvas.width - drawWidth) / 2
                    val top = (canvas.height - drawHeight) / 2
                    val destination = Rect(left, top, left + drawWidth, top + drawHeight)
                    canvas.drawBitmap(bitmap, null, destination, null)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Unable to draw fallback wallpaper image", e)
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        Log.w(TAG, "Unable to post fallback wallpaper canvas", e)
                    }
                }
            }
        }

        private fun releasePlayer() {
            val old = player
            player = null
            prepared = false
            if (old != null) {
                try {
                    old.setOnPreparedListener(null)
                    old.setOnErrorListener(null)
                    old.setOnCompletionListener(null)
                    old.release()
                } catch (e: Exception) {
                    Log.w(TAG, "Error while releasing MediaPlayer", e)
                }
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            releasePlayer()
            try {
                fallbackBitmap?.recycle()
            } catch (e: Exception) {
                Log.w(TAG, "Unable to recycle fallback bitmap", e)
            }
            fallbackBitmap = null
            super.onDestroy()
        }
    }

    companion object {
        private const val TAG = "IceLiveWallpaper"
    }
}
