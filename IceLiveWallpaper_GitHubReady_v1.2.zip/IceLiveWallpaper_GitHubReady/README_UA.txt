ICE LIVE WALLPAPER — повний Android-проєкт для GitHub Actions

У ZIP міститься вихідний Android-проєкт, відео шпалер, зображення попереднього перегляду,
Manifest, ресурси, Kotlin-код WallpaperService та workflow автоматичної збірки APK.

ЗАВАНТАЖЕННЯ В GITHUB
1. Розпакуйте ZIP.
2. Завантажте саме ВМІСТ папки IceLiveWallpaper_GitHubReady у корінь репозиторію.
   У корені GitHub мають бути build.gradle, settings.gradle, gradle.properties,
   папка app/ та папка .github/.
3. Зробіть Commit changes у гілку main.
4. Відкрийте Actions → Build Android APK. Workflow запускається автоматично після push
   у main; за потреби його також можна запустити вручну через Run workflow.
5. Після успішного завершення відкрийте запуск workflow і завантажте artifact
   IceLiveWallpaper-debug. Усередині буде app-debug.apk.
6. Встановіть APK на Android-пристрій, відкрийте Ice Live Wallpaper та підтвердьте
   застосування шпалер у системному вікні Android.

ТЕХНІЧНО
- Android application; Kotlin; Android Gradle Plugin 8.6.1; Gradle 8.7; JDK 17.
- minSdk 23; targetSdk 32; compileSdk 35.
- Відео: MP4 / H.264 High Profile / 1440×3120 / 15 fps / 8 секунд, циклічне відтворення,
  без звуку.
- MP4 зберігається в app/src/main/res/raw та виключений зі стиснення APK, щоб
  MediaPlayer міг відкрити його через AssetFileDescriptor.
- Відео запускається лише коли шпалери видимі та призупиняється, коли вони приховані.
- У разі помилки декодування сервіс виводить діагностику з тегом IceLiveWallpaper
  та показує статичне зображення як резервний кадр.

ПЕРЕВІРКА
Архів має бути цілісним ZIP. Реальна Android-збірка виконується GitHub Actions;
фактичне відтворення потрібно підтвердити встановленням APK на телефоні.
