package com.example.icelivewallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder

/** Video-backed Android live wallpaper. Playback exists only while the wallpaper is visible. */
class IceWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoWallpaperEngine()

    inner class VideoWallpaperEngine : Engine() {
        private var player: MediaPlayer? = null
        private var isVisible = false
        private var isPrepared = false
        private var fallbackBitmap: Bitmap? = null

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            fallbackBitmap = BitmapFactory.decodeResource(resources, R.drawable.winter_peak)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            if (isVisible) startVideo(holder) else drawFallback(holder)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (isVisible && player == null) startVideo(holder)
            else if (player == null) drawFallback(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isVisible = visible
            val active = player
            if (!visible) {
                if (active != null && isPrepared) {
                    try {
                        if (active.isPlaying) active.pause()
                    } catch (e: IllegalStateException) {
                        Log.e(TAG, "Pause failed; releasing player", e)
                        failPlayer(active)
                    }
                }
                return
            }

            if (active == null) {
                if (surfaceHolder.surface?.isValid == true) startVideo(surfaceHolder)
            } else if (isPrepared) {
                try {
                    if (!active.isPlaying) active.start()
                } catch (e: IllegalStateException) {
                    Log.e(TAG, "Resume failed; releasing player", e)
                    failPlayer(active)
                }
            }
            // If prepareAsync is pending, onPrepared starts playback after it completes.
        }

        private fun startVideo(holder: SurfaceHolder) {
            if (!isVisible || !holder.surface.isValid || player != null) return
            drawFallback(holder)

            val mp = MediaPlayer()
            player = mp
            isPrepared = false
            try {
                val descriptor = resources.openRawResourceFd(R.raw.mountain_lake)
                    ?: throw IllegalStateException("MP4 must be stored uncompressed in res/raw")
                try {
                    mp.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
                } finally {
                    descriptor.close()
                }
                mp.setDisplay(holder)
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                mp.setOnPreparedListener { ready ->
                    if (player !== ready) return@setOnPreparedListener
                    isPrepared = true
                    Log.i(TAG, "Video prepared: ${ready.videoWidth}x${ready.videoHeight}; visible=$isVisible")
                    if (isVisible) {
                        try {
                            ready.start()
                            Log.i(TAG, "Live wallpaper video started")
                        } catch (e: IllegalStateException) {
                            Log.e(TAG, "Playback start failed", e)
                            failPlayer(ready)
                        }
                    }
                }
                mp.setOnErrorListener { failed, what, extra ->
                    Log.e(TAG, "MediaPlayer error what=$what extra=$extra")
                    failPlayer(failed)
                    true
                }
                mp.setOnInfoListener { _, what, extra ->
                    Log.i(TAG, "MediaPlayer info what=$what extra=$extra")
                    false
                }
                mp.prepareAsync()
                Log.i(TAG, "Video preparation requested")
            } catch (e: Exception) {
                Log.e(TAG, "Unable to initialize wallpaper video", e)
                failPlayer(mp)
            }
        }

        private fun failPlayer(failed: MediaPlayer) {
            if (player !== failed) return
            player = null
            isPrepared = false
            try {
                failed.setOnPreparedListener(null)
                failed.setOnErrorListener(null)
                failed.setOnInfoListener(null)
                failed.release()
            } catch (e: Exception) {
                Log.w(TAG, "MediaPlayer release failed", e)
            }
            if (surfaceHolder.surface?.isValid == true) drawFallback(surfaceHolder)
        }

        private fun drawFallback(holder: SurfaceHolder) {
            val bitmap = fallbackBitmap ?: return
            if (!holder.surface.isValid) return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val scale = maxOf(
                        canvas.width.toFloat() / bitmap.width,
                        canvas.height.toFloat() / bitmap.height
                    )
                    val width = (bitmap.width * scale).toInt()
                    val height = (bitmap.height * scale).toInt()
                    val left = (canvas.width - width) / 2
                    val top = (canvas.height - height) / 2
                    canvas.drawBitmap(bitmap, null, Rect(left, top, left + width, top + height), null)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Fallback frame draw failed", e)
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) }
                    catch (e: Exception) { Log.w(TAG, "Fallback canvas post failed", e) }
                }
            }
        }

        private fun releasePlayer() {
            val old = player ?: return
            player = null
            isPrepared = false
            try {
                old.setOnPreparedListener(null)
                old.setOnErrorListener(null)
                old.setOnInfoListener(null)
                old.release()
            } catch (e: Exception) {
                Log.w(TAG, "MediaPlayer release failed", e)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            releasePlayer()
            fallbackBitmap?.recycle()
            fallbackBitmap = null
            super.onDestroy()
        }
    }

    companion object {
        private const val TAG = "IceLiveWallpaper"
    }
}
