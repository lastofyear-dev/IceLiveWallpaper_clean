ICE LIVE WALLPAPER — Android project

Це вихідний Android-проєкт живих шпалер (WallpaperService), а не готовий APK.
Проєкт розрахований на JDK 17, Gradle 8.7 та Android Gradle Plugin 8.6.1.

Збірка через GitHub Actions:
1. Створити порожній репозиторій на GitHub (за бажанням — приватний).
2. Завантажити в репозиторій ВМІСТ цього архіву, а не сам ZIP і не зовнішню папку.
   У корені репозиторію мають бути build.gradle, settings.gradle, app/ та .github/.
3. Відкрити Actions → Build Android APK → Run workflow.
4. Після успішного запуску завантажити artifact IceLiveWallpaper-debug.
5. Розпакувати artifact і встановити app-debug.apk на телефон.

Важливо: APK ще не зібрано в цьому середовищі й не перевірено на фізичному OnePlus 7T Pro.
GitHub Actions виконає першу реальну компіляцію. Фіксація Java/Kotlin JVM target на 17 усуває
конкретну несумісність 1.8/17, яка була у попередньому запуску.
